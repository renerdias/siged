<template>
<!--
  <div class="wxs-100" style="position: relative; display: table;">
      <p class="r2-box r2-row r2-center" style='justify-content: flex-start !important;'>
          <input type="text" v-model="modelValue" @change="key_change" class="wxs-100">
          <input type="text" v-model="keyword" class="wxs-100" placeholder="Pesquisar..." @input="onInput($event.target.value)" @keyup.esc="closeDropdown" @blur="closeDropdown" @keydown.down="moveDown" @keydown.prevent.up="moveUp" @keydown.enter="select">
          <i class="fa fa-search" style="float:right;margin-left: -30px; z-index:2;"></i>
      </p>
      <ul v-show="isOpen" class="options-list card-1 wxs-100">
          <li :class="{'highlighted': highlightedPosition === 0 }" @mouseenter="highlightedPosition = 0" @mousedown="select">
              Pesquisando por "{{ enteredValue }}"
          </li>

          <li :class="{'highlighted': index === highlightedPosition - 1 }" v-for="(option, index) in fOptions" @mouseenter="highlightedPosition = index + 1" @mousedown="select">
              <slot :item="option"></slot>
          </li>
      </ul>
  </div>
-->

<div style="position: relative" class="wxs-100" :class="{open:showDropdown}">
  <p class="r2-box r2-row r2-center wxs-100" style='justify-content: flex-start !important;'>
    <!--
    <input readonly type="hidden" :placeholder="placeholder" @input="$emit('input',$event.target.value)" v-model="editableValue" :name="name" :class="{'border__is-red': haserror}" />
    <input v-model="display" :class="{'border__is-red': haserror}" class="wxs-100" type="text" readonly placeholder="Tecle enter para abrir o formulário de pesquisa" @keyup.enter.stop="onsearch()" />
  -->
    <!--
    <input readonly type="hidden" :placeholder="placeholder" @input="$emit('input',$event.target.value)" v-model="keyValue" />
  -->
    <input autocomplete="off" v-model="val" @input="$emit('input',$event.target.value)" :placeholder="placeholder" :type.once="type" @blur="showDropdown = false" @keydown.down.prevent="down" @keydown.enter="hit" @keydown.esc="reset" @keydown.up.prevent="up"
    />
    <i class="fa fa-search" style="float:right;margin-left: -30px; z-index:2;"></i>
  </p>
  <ul class="options-list card-1" style="width: 100%" ref="dropdown">
    <li v-for="(item, i) in items" :class="{highlighted: isActive(i)}" @mousedown.prevent="hit" @mousemove="setActive(i)">
      <component :is="templateComp" :item="item"></component>
    </li>
  </ul>
</div>
</template>

<script>
import {
  delayer,
  getJSON
} from '../utils/utils.js'
import * as util from '../utils/removerAcentos.js'
var DELAY = 300
export default {
  props: {
    async: {
      type: String
    },
    data: {
      type: Array
    },
    delay: {
      type: Number,
      default: DELAY
    },
    asyncKey: {
      type: String,
      default: null
    },
    limit: {
      type: Number,
      default: 4
    },
    minChar: {
      type: Number,
      default: 3
    },
    matchCase: {
      type: Boolean,
      default: false
    },
    matchStart: {
      type: Boolean,
      default: false
    },
    onHit: {
      type: Function,
      default (item) {
        return item
      }
    },
    placeholder: {
      type: String
    },
    template: {
      type: String
    },
    type: {
      type: String,
      default: 'text'
    },
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      asign: '',
      showDropdown: false,
      noResults: true,
      current: -1,
      items: [],
      val: this.value
    }
  },
  computed: {
    /*
    //R2
    keyValue() {
      if (this.val !== null && this.val.length > 0 && this.current >= 0 && this.items.length > 0) {
        let selectedOption = this.items[this.current];
        return selectedOption['id_municipio'];
      }
    },
    */
    templateComp() {
      return {
        template: typeof this.template === 'string' ? '<span>' + this.template + '</span>' : '<strong v-html="item"></strong>',
        props: {
          item: {
            default: null
          }
        }
      }
    }
  },
  watch: {
    val(val, old) {
      if (val.length >= this.minChar) {
        this.$emit('input', val)
        if (val !== old && val !== this.asign) this.__update()
      }
    },
    value(val) {
      if (this.val !== val) {
        this.val = val
      }
    }
  },
  methods: {
    setItems(data) {
      if (this.async) {
        this.items = this.asyncKey ? data[this.asyncKey] : data
        this.items = this.items.slice(0, this.limit)
      } else {
        this.items = (data || []).filter(value => {
          /*
          if (typeof value === 'object') {
            return true
          }
          value = this.matchCase ? value : value.toLowerCase()
          var query = this.matchCase ? this.val : this.val.toLowerCase()
          return this.matchStart ? value.indexOf(query) === 0 : value.indexOf(query) !== -1
          */
          //Verifica se o valor e um objeto
          if (typeof value === 'object') {
            var obj = value;
            for (var key in obj) {
              if (obj.hasOwnProperty(key)) {
                var vlr = obj[key];
                //Transforma o valor em string
                vlr = vlr.toString();
                //Verifica se o valor e uma string
                if (typeof vlr === 'string') {
                  //Retira espaço em branco no inicio e fim, transforma e minúsculo, remove acentos
                  const s = util.removerAcentos(vlr.trim().toLowerCase());
                  //Retira espaço em branco no inicio e fim, transforma e minúsculo, remove acentos
                  const t = util.removerAcentos(this.val.trim().toLowerCase());
                  if (s.indexOf(t) >= 0) {
                    return true;
                  }
                }
              }
            }
            return false;
          } else {
            vlr = value.toString();
            //Verifica se o valor e uma string
            if (typeof vlr === 'string') {
              //Retira espaço em branco no inicio e fim, transforma e minúsculo, remove acentos
              const s = util.removerAcentos(vlr.trim().toLowerCase());
              //Retira espaço em branco no inicio e fim, transforma e minúsculo, remove acentos
              const t = util.removerAcentos(this.val.trim().toLowerCase());
              if (s.indexOf(t) >= 0) {
                return true;
              }
            }
          }
        }).slice(0, this.limit)
      }
      this.showDropdown = this.items.length > 0
    },
    setValue(value) {
      this.asign = value
      this.val = value
      this.items = []
      this.loading = false
      this.showDropdown = false
    },
    reset() {
      this.setValue(null)
      //R2
      this.showDropdown = false;
    },
    setActive(index) {
      this.current = index
    },
    isActive(index) {
      return this.current === index
    },
    hit(e) {
      /*
      //R2
      if (this.val !== null && this.showDropdown == false && this.val.length > 0 && this.current >= 0 && this.items.length > 0) {
        let selectedOption = this.items[this.current];
        if (typeof selectedOption === 'object') {
          this.setValue(selectedOption['no_municipio']);
        }
      }
      */
      e.preventDefault()
      this.setValue(this.onHit(this.items[this.current], this))
    },
    up() {
      if (this.current > 0) {
        this.current--
      } else {
        this.current = this.items.length - 1
      }
    },
    down() {
      if (this.current < this.items.length - 1) {
        this.current++
      } else {
        this.current = 0
      }
    }
  },
  created() {
    this.__update = delayer(function() {
      if (!this.val) {
        this.reset()
        return
      }
      this.asign = ''
      if (this.async) {
        getJSON(this.async + this.val).then(data => {
          this.setItems(data)
        })
      } else if (this.data) {
        this.setItems(this.data)
      }
    }, 'delay', DELAY)
    this.__update()
  }
}
</script>

<style>
.dropdown-menu>li>a {
  //  cursor: pointer;
}

ul.options-list {
  z-index: 20;
  display: flex;
  flex-direction: column;
  border-radius: 0 0 3px 3px;
  position: absolute;
  overflow: hidden;
}

ul.options-list li {
  width: 100%;
  flex-wrap: wrap;
  background: white;
  margin: 0;
  border-bottom: 1px solid #eee;
  color: #363636;
  padding: 7px;
  cursor: pointer;
}

ul.options-list li.highlighted {
  /*background: #f8f8f8*/
  background-color: #e0e0e0;
  background-image: -webkit-linear-gradient(#f0f0f0, #e0e0e0);
  box-shadow: inset rgba(0, 0, 0, 0.2) 0 1px 2px;
}
</style>
