<template>
  <div>
    <div class="tab-nav r2-box r2-row">
        <label v-for="tab in tablist" :for="tab.name" :class="{'active': tab.active}">{{tab.title}}</label>
    </div>
    <div class="tab-content">
        <slot></slot>
    </div>
  </div>
</template>
<script>
    export default{
       data () {
          return {
            tablist: []
          }
      },
      mounted(){
        //console.log(this.$children);
        this.$children.forEach(c=>{
            this.tablist.push({
                    "name": c.name,
                    "title": c.title,
                    "active": c.active
                });
        })
      }
  }
</script>
<style>
  .tab-nav {
    background-color: #eeeeee;
    border: 1px solid #ddd;

  }
  .tab-nav label {
    padding: 10px 20px;
    cursor: pointer;
    font-weight: bold;
  }
  .tab-nav label.active {
    border-bottom: 1px solid transparent;
    background: white;
  }
  .tab-nav label:hover {
    background: #ddd;
  }

  .tab-content {
    color : #000000;
    background-color: #ffffff;
    margin-top: -1px;
    border: 1px solid #ddd;
  }
</style>
