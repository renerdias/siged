<template>
  <div id="queryBrowserContainer">
      <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" v-for="tab in tabs" :class="{active:tab.isActive}">
              <a href="#" role="tab" data-toggle="tab" @click.stop.prevent="setActive(tab)">{{ tab.name }}</a>

          </li>
          <li>
              <button type="button" class="btn btn-primary" @click="openNewTab">New tab</button>
          </li>
      </ul>
      <div class="tab-content">
          <div v-for="tab in tabs" role="tabpanel" class="tab-pane" :class="{active:tab.isActive}">
              <t :tab="tab"></t>
          </div>
      </div>
  <!--<pre>{{ $data | json }}</pre>-->

  </div>
</template>
<script>
  import T from './tab.vue'
    export default{
      components:{T},
      data() {
          return {
            tabs: [{
                name: "tab1",
                id : 0,
                isActive: true
            },
            {
                name: "tab2",
                id : 1,
                isActive: false
            }],
            activeTab: {}
          };
      },
      mounted: function () {
  		this.setActive(this.tabs[0]);
      },

      methods: {
          setActive: function (tab) {
              var self = this;
              tab.isActive = true;
              this.activeTab = tab;
              /*this.activeTab.isActive = true;
              console.log("activeTab name=" + this.activeTab.name);*/
              this.tabs.forEach(function (tab) {
                  console.log("TAB => " + tab);
                  console.log("activeTab id => " + self.activeTab.id);
                  console.log("tab id=" + tab.id);

                  if (tab.id !== self.activeTab.id) { tab.isActive = false;}
              });
          },
          openNewTab: function () {
              let newTab = {
                  name: "tab" + (this.tabs.length + 1),
                  id: this.tabs.length,
                  isActive: true
              };
              this.tabs.push(newTab);
              this.setActive(newTab);
              /*this.activeTab = newTab;

              console.log("### newtab name=" + newTab.name);*/

          },

          closeTab: function () {
              console.log("### CLOSE!");
          }
      }
  }
</script>
<style>
  .tab-nav {
    background-color: #eeeeee;
    border: 1px solid #ddd;

  }
  .tab-nav label {
    padding: 10px 20px;
    cursor: pointer;
    font-weight: bold;
  }
  .tab-nav label.active {
    border-bottom: 1px solid transparent;
    background: white;
  }
  .active {
    border-bottom: 1px solid transparent;
    background: white;
  }
  .tab-nav label:hover {
    background: #ddd;
  }

  .tab-content {
    color : #000000;
    background-color: #ffffff;
    margin-top: -1px;
    border: 1px solid #ddd;
  }
</style>
