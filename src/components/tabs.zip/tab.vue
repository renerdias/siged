<template>
     <h3>{{tab.name}}</h3>
</template>
<script>
    export default{
      data () {
          return {
              //databaseOptions: [],
          };
      },
      props: ['tab'],
//<h3>{{tab.name}}</h3>
      methods: {},
    }
</script>
<style>
.tab-radio {
  position: absolute;
  opacity: 0;
}
[type=radio]:checked ~ .tab-pane {
    display: flex;
}
.tab-pane.active {
    display: flex;
}
.tab-pane {
  display: none;
}
.tab-pane {
  -webkit-animation: fadeInScale 0.7s ease-in-out;
  -moz-animation: fadeInScale 0.7s ease-in-out;
  animation: fadeInScale 0.7s ease-in-out;
}
@keyframes fadeInScale {

  0% {
  	transform: scale(0.9);
  	opacity: 0;
  }

  100% {
  	transform: scale(1);
  	opacity: 1;
  }

}
</style>
